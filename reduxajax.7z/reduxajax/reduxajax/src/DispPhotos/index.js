import DispPhotos from "./DispPhotos";
export default DispPhotos;
