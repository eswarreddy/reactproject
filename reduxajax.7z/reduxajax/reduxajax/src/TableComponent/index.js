import TableComponent from "./TableComponent";
export default TableComponent;
