module.exports = require("../config/imports").express
                 .Router()
                 .post("/",(req,res)=>{
    let mydbclient = require("../config/imports").mongodb.MongoClient;
    mydbclient.connect("mongodb://localhost:27017/workshop",
                            (err,db)=>{
        db.collection("products")
                    .insertOne({
                        'p_id':req.body.p_id,
                        'p_name':req.body.p_name,
                        'p_cost':req.body.p_cost
                    },(err,result)=>{
            if(err)
                throw err;
            else
                res.send({insert:"success"});
        });
    });
});