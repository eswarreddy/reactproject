module.exports = require("../config/imports").express
                 .Router()
                 .post("/",(req,res)=>{
    let mydbclient = require("../config/imports").mongodb.MongoClient;
    let obj = {'p_id':req.body.p_id};
    mydbclient.connect("mongodb://localhost:27017/workshop",
                (err,db)=>{
        db.collection("products").deleteOne(obj,(err,result)=>{
            if(err)
                throw err;
            else    
                res.send({delete:'success'});
        });
    });
});