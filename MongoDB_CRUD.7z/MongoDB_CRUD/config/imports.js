module.exports = {
    express   :   require("express"),
    bodyparser : require("body-parser"),
    cors : require("cors"),
    mongodb : require("mongodb")
};