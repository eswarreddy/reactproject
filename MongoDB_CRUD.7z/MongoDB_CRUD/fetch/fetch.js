module.exports = require("../config/imports").express
                .Router()
                .get("/",(req,res)=>{
    //create the client
    let mydbclient = require("../config/imports").mongodb.MongoClient;
    //connect to workshop
    mydbclient.connect("mongodb://localhost:27017/workshop",
                            (err,db)=>{
        db.collection("products").find()
                        .toArray((err,array)=>{
            if(err)
                throw err;
            else
                res.send(array);
        });
    })
});